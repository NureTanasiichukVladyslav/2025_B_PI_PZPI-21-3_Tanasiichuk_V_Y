﻿namespace Identity.Microservice.API.Models.Response
{
    public record ErrorDetails(int StatusCode, string ErrorMessage);
}
