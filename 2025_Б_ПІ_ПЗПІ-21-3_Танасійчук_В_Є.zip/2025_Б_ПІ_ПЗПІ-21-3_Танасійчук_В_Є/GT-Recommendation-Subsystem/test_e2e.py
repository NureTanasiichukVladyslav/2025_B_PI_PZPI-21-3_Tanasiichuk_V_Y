import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch
import pandas as pd

from main import app 


class TestE2ELocationEndpoints:
    
    @pytest.fixture
    def client(self):
        return TestClient(app)
    
    
    def test_get_recommendations_only_city_provided_e2e(self, client):
        """E2E test for recommendations when only city is provided"""
        # Arrange
        request_data = {
            "user_types": ["restaurant", "food"],
            "city": "Kyiv"
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        
        # If there are results, validate structure
        if len(data) > 0:
            for location in data:
                assert 'name' in location
                assert 'rating' in location
                assert 'distance_km' in location
                assert 'score' in location
                assert 'types' in location
                assert 'lat' in location
                assert 'lng' in location
                assert isinstance(location['lat'], (int, float))
                assert isinstance(location['lng'], (int, float))
                assert isinstance(location['rating'], (int, float))
                assert isinstance(location['distance_km'], (int, float))
                assert isinstance(location['score'], (int, float))
    
    
    def test_get_recommendations_city_and_max_distance_e2e(self, client):
        """E2E test for recommendations with city and max distance"""
        # Arrange
        request_data = {
            "user_types": ["cafe"],
            "city": "Kyiv",
            "max_distance": 5.0
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        
        # If there are results, check that all returned locations are within max distance
        for location in data:
            assert location['distance_km'] <= 5.0
            assert 'score' in location
    
    
    def test_get_recommendations_only_user_coordinates_e2e(self, client):
        """E2E test for recommendations when only user coordinates are provided"""
        # Arrange - Using coordinates for Kyiv center
        request_data = {
            "user_types": ["restaurant"],
            "user_lat": 50.4501,
            "user_lng": 30.5234
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        
        # Check response structure if there are results
        for location in data:
            assert 'name' in location
            assert 'distance_km' in location
            assert 'score' in location
            assert isinstance(location['lat'], (int, float))
            assert isinstance(location['lng'], (int, float))
            assert location['distance_km'] >= 0  # Distance should be non-negative
    
    
    def test_get_recommendations_user_coordinates_and_max_distance_e2e(self, client):
        """E2E test for recommendations with user coordinates and max distance"""
        # Arrange - Using coordinates for Lviv center
        request_data = {
            "user_types": ["food", "restaurant"],
            "user_lat": 49.8397,
            "user_lng": 24.0297,
            "max_distance": 10.0,
            "top_n": 15
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        assert len(data) <= 15  # Should respect top_n limit
        
        # Check that all returned locations are within max distance
        for location in data:
            assert location['distance_km'] <= 10.0
            assert location['distance_km'] >= 0
    
    
    def test_get_recommendations_invalid_city_e2e(self, client):
        """E2E test for recommendations with invalid city"""
        # Arrange
        request_data = {
            "user_types": ["restaurant"],
            "city": "NonExistentCity123456"
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert - This might return 404 or 200 with empty results depending on implementation
        if response.status_code == 404:
            assert "not found" in response.json()['detail'].lower()
        elif response.status_code == 200:
            data = response.json()
            assert isinstance(data, list)
            assert len(data) == 0  # No results for non-existent city
    
    
    def test_get_recommendations_very_restrictive_distance_e2e(self, client):
        """E2E test when distance filter is very restrictive"""
        # Arrange
        request_data = {
            "user_types": ["restaurant"],
            "user_lat": 50.4501,
            "user_lng": 30.5234,
            "max_distance": 0.1  # Very small distance (1 meter)
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        # With such a small distance, likely no results
        for location in data:
            assert location['distance_km'] <= 0.1
    
    
    def test_get_recommendations_invalid_request_data_e2e(self, client):
        """E2E test for invalid request data"""
        # Arrange - Missing required user_types
        request_data = {
            "city": "Kyiv"
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 422  # Validation error
    
  
    
    def test_get_recommendations_large_top_n_e2e(self, client):
        """E2E test with large top_n parameter"""
        # Arrange
        request_data = {
            "user_types": ["restaurant", "food"],
            "city": "Kyiv",
            "top_n": 1000  # Large number
        }
        
        # Act
        response = client.post("/locations/recommendations", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
        # Should return all available results (limited by actual data)
        assert len(data) <= 1000
class TestE2EReviewEndpoints:
    
    @pytest.fixture
    
    def client(self):
        return TestClient(app)
    
    
    def test_analyze_review_legitimate_e2e(self, client):
        """E2E test for analyzing a legitimate review"""
        request_data = {
            "rating": 4,
            "text": "Great restaurant with excellent service. The food was delicious and the staff was very friendly. We had a wonderful dinner here last night and would definitely recommend this place to others."
        }
        
        # Act
        response = client.post("/reviews/analyze", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        
        assert 'fake_probability' in data
        assert 'confidence_score' in data
        assert 'is_fake' in data
        assert 'analysis_factors' in data
        
        assert isinstance(data['fake_probability'], float)
        assert isinstance(data['confidence_score'], float)
        assert isinstance(data['is_fake'], bool)
        assert isinstance(data['analysis_factors'], dict)
        
        # Check analysis factors structure
        factors = data['analysis_factors']
        assert 'text_complexity' in factors
        assert 'suspicious_patterns' in factors
        assert 'sentiment_correlation' in factors
        assert 'content_relevance' in factors
    
    
    def test_analyze_review_suspicious_e2e(self, client):
        """E2E test for analyzing a suspicious review"""
        request_data = {
            "rating": 5,
            "text": "AMAZING!!! BEST BEST BEST!!! This is the most INCREDIBLE place EVER!!! amazing amazing amazing perfect perfect perfect wow wow wow"
        }
        
        # Act
        response = client.post("/reviews/analyze", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        
        assert data['is_fake'] is True
        assert data['fake_probability'] > 0.5
        
        # Check that suspicious patterns were detected
        suspicious_patterns = data['analysis_factors']['suspicious_patterns']
        assert suspicious_patterns['excessive_punctuation'] > 0
        assert suspicious_patterns['all_caps_words'] > 0
        assert suspicious_patterns['spam_keywords'] > 0
    
    
    def test_analyze_review_too_short_e2e(self, client):
        """E2E test for analyzing a review that's too short"""
        request_data = {
            "rating": 3,
            "text": "Ok"
        }
        
        # Act
        response = client.post("/reviews/analyze", json=request_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        
        assert data['is_fake'] is True
        assert data['fake_probability'] == 1.0
        assert 'error' in data['analysis_factors']
        assert data['analysis_factors']['error'] == 'Review too short'
    
    
    def test_analyze_review_invalid_request_e2e(self, client):
        """E2E test for invalid review analysis request"""
        request_data = {
            "rating": "invalid",  # Should be int
            "text": "Some review text"
        }
        
        # Act
        response = client.post("/reviews/analyze", json=request_data)
        
        # Assert
        assert response.status_code == 422  # Validation error