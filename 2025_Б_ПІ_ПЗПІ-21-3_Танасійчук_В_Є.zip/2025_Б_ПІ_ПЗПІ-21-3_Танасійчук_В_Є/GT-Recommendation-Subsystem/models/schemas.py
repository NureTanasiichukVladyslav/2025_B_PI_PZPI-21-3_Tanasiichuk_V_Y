
# models/schemas.py
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class LocationRecommendationRequest(BaseModel):
    user_types: List[str]
    user_lat: Optional[float] = None
    user_lng: Optional[float] = None
    top_n: Optional[int] = 20
    max_distance: Optional[float] = None
    city: Optional[str] = None

class LocationResponse(BaseModel):
    name: Optional[str] = None
    rating: Optional[float] = None
    distance_km: float
    score: float
    types: List[str]
    lat: float
    lng: float

class ReviewAnalysisRequest(BaseModel):
    rating: int
    text: str

class ReviewAnalysisResponse(BaseModel):
    fake_probability: float
    confidence_score: float
    is_fake: bool
    analysis_factors: Dict[str, Any]