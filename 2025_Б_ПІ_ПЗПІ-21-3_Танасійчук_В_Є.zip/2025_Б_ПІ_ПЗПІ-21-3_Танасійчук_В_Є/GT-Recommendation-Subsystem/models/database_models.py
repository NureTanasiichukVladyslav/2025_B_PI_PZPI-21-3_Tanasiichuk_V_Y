from sqlalchemy import Column, Integer, String, Float, DateTime, Table, ForeignKey
from sqlalchemy.dialects.postgresql import UUID as pg_UUID
from sqlalchemy.ext.declarative import as_declarative, declared_attr
from sqlalchemy.orm import relationship
import uuid
from datetime import datetime

@as_declarative()
class BaseEntity:
    @declared_attr
    def __tablename__(cls):
        return cls.__name__.lower() + "s"  # Default table name as plural (e.g., Places, Categories)

    Id = Column(pg_UUID(as_uuid=True), primary_key=True, index=True, default=uuid.uuid4)
    CreatedAt = Column(DateTime, default=datetime.utcnow)
    ModifiedAt = Column(DateTime, nullable=True)

    def __init__(self):
        self.Id = uuid.uuid4()  # Ensure Id is set on instantiation
        self.CreatedAt = datetime.utcnow()  # Set CreatedAt on instantiation

# Define association tables first
place_category_association = Table(
    'PlaceCategories',
    BaseEntity.metadata,
    Column('PlaceId', pg_UUID(as_uuid=True), ForeignKey('Places.Id'), primary_key=True),
    Column('CategoryId', pg_UUID(as_uuid=True), ForeignKey('Categories.Id'), primary_key=True)
)

place_tag_association = Table(
    'PlaceTags',
    BaseEntity.metadata,
    Column('PlaceId', pg_UUID(as_uuid=True), ForeignKey('Places.Id'), primary_key=True),
    Column('TagId', pg_UUID(as_uuid=True), ForeignKey('Tags.Id'), primary_key=True)
)



class Place(BaseEntity):
    __tablename__ = 'Places'  # Override default to match existing schema

    Name = Column(String, nullable=False)
    Lat = Column(Float, nullable=False)
    Lng = Column(Float, nullable=False)
    Vicinity = Column(String, nullable=True)
    GooglePlaceId = Column(String, unique=True, nullable=False, index=True)
    Rating = Column(Float, nullable=True)
    UserRatingsTotal = Column(Integer, nullable=True)

    # Many-to-many relationships - Fixed to use the actual table objects
    types = relationship("Types", secondary=place_category_association, back_populates="places")
    tags = relationship("Tags", secondary=place_tag_association, back_populates="places")

class Types(BaseEntity):
    __tablename__ = 'Categories'  # Map to Categories table

    Name = Column(String, unique=True, nullable=False)

    # Back-reference to places - Fixed to use the actual table object
    places = relationship("Place", secondary=place_category_association, back_populates="types")

class Tags(BaseEntity):
    __tablename__ = 'Tags'  # Map to Tags table

    Name = Column(String, unique=True, nullable=False)

    # Back-reference to places - Fixed to use the actual table object
    places = relationship("Place", secondary=place_tag_association, back_populates="tags")