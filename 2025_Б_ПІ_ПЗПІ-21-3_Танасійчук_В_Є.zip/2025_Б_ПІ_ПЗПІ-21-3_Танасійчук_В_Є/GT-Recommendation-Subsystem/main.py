from fastapi import FastAPI
from sqlalchemy import create_engine, text
import uvicorn
from typing import Union
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

# Import all models to ensure they're registered with the metadata
from models.database_models import BaseEntity, Place, Types, Tags
from repositories import LocationRepository
from services import LocationService, ReviewService
from controllers import LocationController, ReviewController

def create_database_tables():
    """Create database tables with proper error handling and verification"""
    try:
        # Create engine with more explicit configuration
        engine = create_engine(
            "postgresql://postgres:1234567@localhost:5432/EngagementMicroserviceDB",
            echo=True,  # This will log SQL statements for debugging
            pool_pre_ping=True  # Verify connections before use
        )
        
        print("Testing database connection...")
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            with Session(bind=conn) as session:
                BaseEntity.metadata.create_all(bind=session.connection())
                session.commit()
        
        return engine
        
    except SQLAlchemyError as e:
        print(f"Database error: {e}")
        raise
    except Exception as e:
        print(f"Unexpected error: {e}")
        raise

def initialize_app():
    """Initialize the FastAPI application with all components"""
    # Initialize database and create tables
    engine = create_database_tables()
    
    # Initialize repositories
    location_repository = LocationRepository(engine)
    
    # Initialize services
    location_service = LocationService(location_repository)
    review_service = ReviewService()
    
    # Initialize controllers
    location_controller = LocationController(location_service)
    review_controller = ReviewController(review_service)
    
    # Create FastAPI app
    app = FastAPI(title="Location Recommendation API", version="1.0.0")
    
    # Include routers
    app.include_router(location_controller.router)
    app.include_router(review_controller.router)
    
    @app.get("/")
    def read_root():
        return {"message": "Location Recommendation API", "version": "1.0.0"}
    
    @app.get("/health")
    def health_check():
        return {"status": "healthy"}
    
    
    return app

# Initialize the app
app = initialize_app()

if __name__ == '__main__':
    uvicorn.run(app, host="127.0.0.1", port=8001)