from fastapi import HTTPException
import numpy as np
import math
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from typing import List, Tuple
import pandas as pd
from repositories.location import LocationRepository

class LocationService:
    def __init__(self, location_repository: LocationRepository):
        self.location_repository = location_repository
        self.type_similarity_coef: float = 0.4
        self.distances_coef: float = 0.3
        self.rating_coef: float = 0.3
        self.cities = [
            {"name": "Kyiv", "location": {"lat": 50.45, "lng": 30.5233}},
            {"name": "Kharkiv", "location": {"lat": 49.9935, "lng": 36.2304}},
            {"name": "Odesa", "location": {"lat": 46.4825, "lng": 30.7233}},
            {"name": "Dnipro", "location": {"lat": 48.4647, "lng": 35.0462}},
            {"name": "Lviv", "location": {"lat": 49.8397, "lng": 24.0297}},
            {"name": "Zaporizhzhia", "location": {"lat": 47.8388, "lng": 35.1396}},
            {"name": "Kryvyi Rih", "location": {"lat": 47.9077, "lng": 33.3917}},
            {"name": "Mykolaiv", "location": {"lat": 46.975, "lng": 31.9946}},
            {"name": "Mariupol", "location": {"lat": 47.0971, "lng": 37.5407}},
            {"name": "Vinnytsia", "location": {"lat": 49.2331, "lng": 28.4682}},
            {"name": "Chernihiv", "location": {"lat": 51.4982, "lng": 31.2893}},
            {"name": "Chernivtsi", "location": {"lat": 48.2921, "lng": 25.9358}},
            {"name": "Zhytomyr", "location": {"lat": 50.2547, "lng": 28.6587}},
            {"name": "Sumy", "location": {"lat": 50.9077, "lng": 34.7981}},
            {"name": "Poltava", "location": {"lat": 49.5883, "lng": 34.5514}},
            {"name": "Khmelnytskyi", "location": {"lat": 49.4229, "lng": 26.9871}},
            {"name": "Cherkasy", "location": {"lat": 49.4444, "lng": 32.0598}},
            {"name": "Rivne", "location": {"lat": 50.619, "lng": 26.2527}},
        ]

    def _initialize_vectorizer(self, df: pd.DataFrame) -> Tuple[CountVectorizer, np.ndarray]:
        """Initialize the vectorizer with location data and return vectorizer and types matrix"""
        vectorizer = CountVectorizer()
        if df.empty or 'types_str' not in df.columns or df['types_str'].isna().all():
            types_matrix = vectorizer.fit_transform([""])  # Dummy document
            print("Warning: No valid data for vectorizer, using empty types_matrix.")
        else:
            types_matrix = vectorizer.fit_transform(df['types_str'])
        return vectorizer, types_matrix

    def get_recommendations(
        self,
        user_types: List[str],
        user_lat: float = None,
        user_lng: float = None,
        top_n: int = 20,
        max_distance: float = None,
        city: str = None,
    ) -> List[dict]:
        """Get location recommendations based on user preferences"""
        df = self.location_repository.get_all_locations()
        if df.empty:
            return []  # Return empty list if DataFrame is empty

        # Initialize vectorizer with initial DataFrame
        vectorizer, _ = self._initialize_vectorizer(df)

        # Determine coordinates to use based on city parameter
        if city:
            city_location = self.get_city_location(city)
            if city_location is None:
                raise HTTPException(status_code=404, detail=f"City '{city}' not found in the cities list")
            lat = city_location['lat']
            lng = city_location['lng']
        else:
            lat = user_lat
            lng = user_lng

        # Filter by city if provided (check if vicinity contains the city name)
        if city:
            city_lower = city.lower()
            df = df[df['vicinity'].fillna('').str.lower().str.contains(city_lower, na=False)]
            if df.empty:
                return []  # Return empty list if no places match the city

        # Calculate distances and filter by max_distance
        distances = df.apply(
            lambda row: self.haversine_distance(lat, lng, row['lat'], row['lng']),
            axis=1
        )

        # Filter out places that exceed max_distance
        if max_distance:
            distance_mask = distances <= max_distance
            df = df[distance_mask]
            distances = distances[distance_mask]
            if df.empty:
                return []  # Return empty list if no places within max_distance

        # Transform filtered data using the same vectorizer
        filtered_types_matrix = vectorizer.transform(df['types_str'])

        # Vectorize user preferences
        user_types_str = ' '.join(user_types)
        user_vector = vectorizer.transform([user_types_str])

        # Calculate cosine similarity
        similarity_scores = cosine_similarity(user_vector, filtered_types_matrix).flatten()

        # Normalize distances
        max_actual_distance = distances.max() if not distances.empty else 1.0
        norm_distances = 1 - (distances / max_actual_distance)

        # Normalize ratings
        ratings = df['rating'].fillna(0).copy()
        max_rating = 5.0
        norm_ratings = ratings / max_rating

        # Calculate weighted score
        weighted_scores = (
            self.type_similarity_coef * similarity_scores +
            self.distances_coef * norm_distances +
            self.rating_coef * norm_ratings
        )

        # Create recommendation DataFrame
        recommendation_df = df.copy()
        recommendation_df['similarity'] = similarity_scores
        recommendation_df['distance_km'] = distances
        recommendation_df['score'] = weighted_scores

        # Convert to list of dictionaries and return top N
        return recommendation_df.sort_values('score', ascending=False).head(top_n).to_dict('records')

    def haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate the great circle distance between two points on earth"""
        lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
        
        dlon = lon2 - lon1
        dlat = lat2 - lat1
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        km = 6371 * c
        return km

    def get_city_location(self, city_name: str) -> dict:
        """Get city location by name (case-insensitive)"""
        city_name_lower = city_name.lower()
        for city in self.cities:
            if city["name"].lower() == city_name_lower:
                return city["location"]
        return None
    
    def seed_database_from_json(
        self
    ) -> List[dict]:
        """Get location recommendations based on user preferences"""
        return self.location_repository.seed_database_from_json('./places_raw.json')
      