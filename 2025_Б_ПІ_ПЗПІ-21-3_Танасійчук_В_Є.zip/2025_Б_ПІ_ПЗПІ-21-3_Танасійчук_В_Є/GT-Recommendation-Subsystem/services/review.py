import numpy as np
from textblob import TextBlob
import re
from typing import Dict, Any

class ReviewService:
    def __init__(self):
        self.FAKE_PROBABILITY_THRESHOLD = 0.7
        self.MIN_REVIEW_LENGTH = 10

    def analyze_text_complexity(self, text: str) -> Dict[str, float]:
        """Analyze text complexity"""
        words = text.split()
        return {
            'avg_word_length': np.mean([len(word) for word in words]) if words else 0,
            'unique_words_ratio': len(set(words)) / len(words) if words else 0
        }

    def check_suspicious_patterns(self, text: str) -> Dict[str, int]:
        """Check for suspicious patterns in text"""
        return {
            'excessive_punctuation': len(re.findall(r'[!?]{2,}', text)),
            'all_caps_words': len(re.findall(r'\b[A-Z]{2,}\b', text)),
            'repeated_words': len(re.findall(r'\b(\w+)(\s+\1\b)+', text)),
            'spam_keywords': len(re.findall(r'\b(amazing|incredible|best|worst|never|ever)\b', text.lower()))
        }

    def analyze_rating_sentiment_correlation(self, rating: int, text: str) -> Dict[str, float]:
        """Analyze correlation between rating and text sentiment"""
        text_sentiment = TextBlob(text).sentiment.polarity
        normalized_rating = (rating - 3) / 2
        sentiment_rating_diff = abs(text_sentiment - normalized_rating)
        
        return {
            'text_sentiment': text_sentiment,
            'normalized_rating': normalized_rating,
            'sentiment_rating_difference': sentiment_rating_diff
        }

    def calculate_content_relevance(self, text: str) -> Dict[str, float]:
        """Calculate content relevance for location review"""
        location_keywords = {
            'place', 'location', 'restaurant', 'cafe', 'service', 'staff', 'food', 
            'hotel', 'room', 'store', 'price', 'cost', 'parking', 'entrance'
        }
        words = set(text.lower().split())
        relevance_score = len(words.intersection(location_keywords)) / len(words) if words else 0
        
        return {
            'location_relevance': relevance_score,
            'has_specifics': bool(re.search(r'\b\d+(?::\d{2}|pm|am|EUR|USD|\$)\b', text))
        }

    def analyze_review(self, rating: int, text: str) -> Dict[str, Any]:
        """Main method to analyze a review"""
        if len(text) < self.MIN_REVIEW_LENGTH:
            return {
                'fake_probability': 1.0,
                'confidence_score': 1.0,
                'analysis_factors': {'error': 'Review too short'},
                'is_fake': True
            }

        # Collect all metrics
        text_complexity = self.analyze_text_complexity(text)
        suspicious_patterns = self.check_suspicious_patterns(text)
        sentiment_correlation = self.analyze_rating_sentiment_correlation(rating, text)
        content_relevance = self.calculate_content_relevance(text)

        # Calculate fake probability
        fake_indicators = [
            suspicious_patterns['excessive_punctuation'] > 2,
            suspicious_patterns['all_caps_words'] > 3,
            suspicious_patterns['repeated_words'] > 1,
            suspicious_patterns['spam_keywords'] > 3,
            sentiment_correlation['sentiment_rating_difference'] > 0.7,
            text_complexity['unique_words_ratio'] < 0.4,
            content_relevance['location_relevance'] < 0.1
        ]

        fake_probability = sum(fake_indicators) / len(fake_indicators)
        confidence_score = 0.5 + (sum(fake_indicators) * 0.1)

        return {
            'fake_probability': fake_probability,
            'confidence_score': confidence_score,
            'is_fake': fake_probability > self.FAKE_PROBABILITY_THRESHOLD,
            'analysis_factors': {
                'text_complexity': text_complexity,
                'suspicious_patterns': suspicious_patterns,
                'sentiment_correlation': sentiment_correlation,
                'content_relevance': content_relevance
            }
        }