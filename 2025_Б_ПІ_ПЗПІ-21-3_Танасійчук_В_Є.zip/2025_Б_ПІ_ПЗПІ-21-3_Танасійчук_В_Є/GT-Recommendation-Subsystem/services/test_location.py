import pytest
from unittest.mock import Mock
import pandas as pd
from fastapi import HTTPException

from .location import LocationService
from repositories import LocationRepository


class TestLocationService:
    
    @pytest.fixture
    def mock_location_repository(self):
        return Mock(spec=LocationRepository)
    
    @pytest.fixture
    def sample_location_data(self):
        return pd.DataFrame({
            'name': ['Restaurant A', 'Cafe B', 'Store C'],
            'rating': [4.5, 3.8, 4.2],
            'lat': [50.4501, 50.4502, 49.8397],
            'lng': [30.5234, 30.5235, 24.0297],
            'types': [['restaurant', 'food'], ['cafe', 'coffee'], ['store', 'shopping']],
            'types_str': ['restaurant food', 'cafe coffee', 'store shopping'],
            'vicinity': ['Kyiv, Ukraine', 'Kyiv, Ukraine', 'Lviv, Ukraine']
        })
    
    @pytest.fixture
    def location_service(self, mock_location_repository, sample_location_data):
        mock_location_repository.get_all_locations.return_value = sample_location_data
        return LocationService(mock_location_repository)
    
    def test_haversine_distance(self, location_service):
        """Test haversine distance calculation"""
        # Distance between Kyiv and Lviv (approximately)
        kyiv_lat, kyiv_lng = 50.45, 30.5233
        lviv_lat, lviv_lng = 49.8397, 24.0297
        
        distance = location_service.haversine_distance(kyiv_lat, kyiv_lng, lviv_lat, lviv_lng)
        
        # Should be approximately 469 km between Kyiv and Lviv
        assert 460 <= distance <= 480
        
        # Test same location (should be 0)
        same_distance = location_service.haversine_distance(kyiv_lat, kyiv_lng, kyiv_lat, kyiv_lng)
        assert same_distance == 0
    
    def test_get_city_location_found(self, location_service):
        """Test getting city location when city exists"""
        result = location_service.get_city_location("Kyiv")
        
        assert result is not None
        assert result['lat'] == 50.45
        assert result['lng'] == 30.5233
    
    def test_get_city_location_case_insensitive(self, location_service):
        """Test getting city location is case insensitive"""
        result = location_service.get_city_location("KYIV")
        
        assert result is not None
        assert result['lat'] == 50.45
        assert result['lng'] == 30.5233
    
    def test_get_city_location_not_found(self, location_service):
        """Test getting city location when city doesn't exist"""
        result = location_service.get_city_location("NonExistentCity")
        
        assert result is None
    
    def test_get_recommendations_only_city_provided(self, location_service, sample_location_data):
        """Test recommendations when only city is provided"""
        # Mock the repository to return our sample data
        location_service.location_repository.get_all_locations.return_value = sample_location_data
        
        result = location_service.get_recommendations(
            user_types=['restaurant', 'food'],
            city='Kyiv'
        )
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 2  # Only Kyiv locations
        assert all('kyiv' in vicinity.lower() for vicinity in result['vicinity'])
        assert 'score' in result.columns
        assert 'distance_km' in result.columns
    
    def test_get_recommendations_city_and_max_distance(self, location_service, sample_location_data):
        """Test recommendations with city and max distance"""
        location_service.location_repository.get_all_locations.return_value = sample_location_data
        
        result = location_service.get_recommendations(
            user_types=['cafe'],
            city='Kyiv',
            max_distance=5.0
        )
        
        assert isinstance(result, pd.DataFrame)
        assert all(dist <= 5.0 for dist in result['distance_km'])
    
    def test_get_recommendations_only_user_coordinates(self, location_service, sample_location_data):
        """Test recommendations when only user coordinates are provided"""
        location_service.location_repository.get_all_locations.return_value = sample_location_data
        
        result = location_service.get_recommendations(
            user_types=['restaurant'],
            user_lat=50.4501,
            user_lng=30.5234
        )
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 3  # All locations should be returned
        assert 'score' in result.columns
        assert 'distance_km' in result.columns
    
    def test_get_recommendations_user_coordinates_and_max_distance(self, location_service, sample_location_data):
        """Test recommendations with user coordinates and max distance"""
        location_service.location_repository.get_all_locations.return_value = sample_location_data
        
        result = location_service.get_recommendations(
            user_types=['food', 'restaurant'],
            user_lat=50.4501,
            user_lng=30.5234,
            max_distance=100.0,  # 100km radius
            top_n=15
        )
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) <= 15
        assert all(dist <= 100.0 for dist in result['distance_km'])
        assert 'score' in result.columns
    
    def test_get_recommendations_city_not_found(self, location_service):
        """Test recommendations when city is not found"""
        with pytest.raises(HTTPException) as exc_info:
            location_service.get_recommendations(
                user_types=['restaurant'],
                city='NonExistentCity'
            )
        
        assert exc_info.value.status_code == 404
        assert "City 'NonExistentCity' not found" in str(exc_info.value.detail)
    
    def test_get_recommendations_no_locations_within_distance(self, location_service):
        """Test recommendations when no locations are within max distance"""
        # Create data with locations far away
        far_data = pd.DataFrame({
            'name': ['Far Restaurant'],
            'rating': [4.5],
            'lat': [0.0],
            'lng': [0.0],
            'types': [['restaurant']],
            'types_str': ['restaurant'],
            'vicinity': ['Far Away']
        })
        
        location_service.location_repository.get_all_locations.return_value = far_data
        
        result = location_service.get_recommendations(
            user_types=['restaurant'],
            user_lat=50.4501,
            user_lng=30.5234,
            max_distance=1.0  # Very small radius
        )
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0  # No locations within 1km
    
    def test_get_recommendations_scoring_logic(self, location_service, sample_location_data):
        """Test that recommendations are properly scored and sorted"""
        location_service.location_repository.get_all_locations.return_value = sample_location_data
        
        result = location_service.get_recommendations(
            user_types=['restaurant', 'food'],
            user_lat=50.4501,
            user_lng=30.5234,
            top_n=5
        )
        
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
        
        # Check that scores are calculated
        assert 'score' in result.columns
        assert all(isinstance(score, float) for score in result['score'])
        
        # Check that results are sorted by score in descending order
        scores = result['score'].tolist()
        assert scores == sorted(scores, reverse=True)
    
    def test_get_recommendations_empty_user_types(self, location_service, sample_location_data):
        """Test recommendations with empty user types"""
        location_service.location_repository.get_all_locations.return_value = sample_location_data
        
        result = location_service.get_recommendations(
            user_types=[],
            user_lat=50.4501,
            user_lng=30.5234
        )
        
        assert isinstance(result, pd.DataFrame)
        # Should still return results even with empty types
        assert len(result) >= 0