import pytest
from unittest.mock import patch
from .review import ReviewService


class TestReviewService:
    
    @pytest.fixture
    def review_service(self):
        return ReviewService()
    
    def test_analyze_text_complexity(self, review_service):
        """Test text complexity analysis"""
        text = "This is a great restaurant with excellent food and amazing service"
        result = review_service.analyze_text_complexity(text)
        
        assert 'avg_word_length' in result
        assert 'unique_words_ratio' in result
        assert result['avg_word_length'] > 0
        assert 0 <= result['unique_words_ratio'] <= 1
    
    def test_check_suspicious_patterns(self, review_service):
        """Test suspicious pattern detection"""
        text = "AMAZING!!! This is the BEST place EVER!!! amazing amazing food"
        result = review_service.check_suspicious_patterns(text)
        
        assert 'excessive_punctuation' in result
        assert 'all_caps_words' in result
        assert 'repeated_words' in result
        assert 'spam_keywords' in result
        assert result['excessive_punctuation'] > 0
        assert result['all_caps_words'] > 0
        assert result['spam_keywords'] > 0
    
    @patch('services.review.TextBlob')
    def test_analyze_rating_sentiment_correlation(self, mock_textblob, review_service):
        """Test rating-sentiment correlation analysis"""
        # Arrange
        mock_sentiment = mock_textblob.return_value.sentiment
        mock_sentiment.polarity = 0.8
        
        # Act
        result = review_service.analyze_rating_sentiment_correlation(5, "Great place!")
        
        # Assert
        assert 'text_sentiment' in result
        assert 'normalized_rating' in result
        assert 'sentiment_rating_difference' in result
        assert result['text_sentiment'] == 0.8
        assert result['normalized_rating'] == 1.0  # (5-3)/2
    
    def test_calculate_content_relevance(self, review_service):
        """Test content relevance calculation"""
        text = "The restaurant has great food and excellent service. Staff was friendly and prices are reasonable."
        result = review_service.calculate_content_relevance(text)
        
        assert 'location_relevance' in result
        assert 'has_specifics' in result
        assert result['location_relevance'] > 0
    
    def test_analyze_review_legitimate_case(self, review_service):
        """Test analysis of a legitimate review (should not be flagged as fake)"""
        rating = 4
        text = "Great restaurant with delicious food. The service was excellent and the staff was very friendly. We had dinner here last night and the atmosphere was perfect. Prices are reasonable for the quality. Would definitely recommend this place to others."
        
        result = review_service.analyze_review(rating, text)
        
        assert 'fake_probability' in result
        assert 'confidence_score' in result
        assert 'is_fake' in result
        assert 'analysis_factors' in result
        
        # This should be identified as legitimate (not fake)
        assert result['is_fake'] is False
        assert result['fake_probability'] < 0.7
        assert 'text_complexity' in result['analysis_factors']
        assert 'suspicious_patterns' in result['analysis_factors']
        assert 'sentiment_correlation' in result['analysis_factors']
        assert 'content_relevance' in result['analysis_factors']
    
    def test_analyze_review_fake_case(self, review_service):
        """Test analysis of a suspicious review (should be flagged as fake)"""
        rating = 5
        text = "AMAZING!!! BEST BEST BEST!!! This is the most INCREDIBLE place EVER!!! amazing amazing amazing perfect perfect perfect wow wow wow"
        
        result = review_service.analyze_review(rating, text)
        
        assert 'fake_probability' in result
        assert 'confidence_score' in result
        assert 'is_fake' in result
        assert 'analysis_factors' in result
        
        # This should be identified as fake due to suspicious patterns
        assert result['is_fake'] is True
        assert result['fake_probability'] >= 0.7
        
        # Check that suspicious patterns were detected
        suspicious_patterns = result['analysis_factors']['suspicious_patterns']
        assert suspicious_patterns['excessive_punctuation'] > 0
        assert suspicious_patterns['all_caps_words'] > 0
        assert suspicious_patterns['repeated_words'] > 0
        assert suspicious_patterns['spam_keywords'] > 0
    
    def test_analyze_review_too_short(self, review_service):
        """Test analysis of a review that's too short"""
        rating = 3
        text = "Good"
        
        result = review_service.analyze_review(rating, text)
        
        assert result['fake_probability'] == 1.0
        assert result['confidence_score'] == 1.0
        assert result['is_fake'] is True
        assert 'error' in result['analysis_factors']
        assert result['analysis_factors']['error'] == 'Review too short'
    
    def test_analyze_text_complexity_empty_text(self, review_service):
        """Test text complexity analysis with empty text"""
        result = review_service.analyze_text_complexity("")
        
        assert result['avg_word_length'] == 0
        assert result['unique_words_ratio'] == 0
    
    def test_calculate_content_relevance_with_specifics(self, review_service):
        """Test content relevance with specific details (prices, times)"""
        text = "Restaurant opens at 8:00am and closes at 10pm. Dinner costs around $25 per person."
        result = review_service.calculate_content_relevance(text)
        
        assert result['has_specifics'] is True