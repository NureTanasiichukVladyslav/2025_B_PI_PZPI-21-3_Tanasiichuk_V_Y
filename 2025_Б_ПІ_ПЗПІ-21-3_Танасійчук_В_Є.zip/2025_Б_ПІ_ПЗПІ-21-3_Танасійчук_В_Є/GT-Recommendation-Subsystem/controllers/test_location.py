import pytest
from unittest.mock import Mock, AsyncMock
import pandas as pd
from fastapi import HTTPException

from .location import LocationController
from models.schemas import LocationRecommendationRequest
from services import LocationService


class TestLocationController:
    
    @pytest.fixture
    def mock_location_service(self):
        return Mock(spec=LocationService)
    
    @pytest.fixture
    def location_controller(self, mock_location_service):
        return LocationController(mock_location_service)
    
    @pytest.fixture
    def sample_dataframe(self):
        return pd.DataFrame({
            'name': ['Restaurant A', 'Cafe B'],
            'rating': [4.5, 3.8],
            'distance_km': [1.2, 2.5],
            'score': [0.85, 0.72],
            'types': [['restaurant', 'food'], ['cafe', 'coffee']],
            'lat': [50.4501, 50.4502],
            'lng': [30.5234, 30.5235]
        })
    
    @pytest.mark.asyncio
    async def test_get_recommendations_only_city_provided(self, location_controller, mock_location_service, sample_dataframe):
        """Test controller when only city is provided"""
        # Arrange
        mock_location_service.get_recommendations.return_value = sample_dataframe
        request = LocationRecommendationRequest(
            user_types=['restaurant', 'food'],
            city='Kyiv'
        )
        
        # Act
        result = await location_controller.router.routes[0].endpoint(request)
        
        # Assert
        mock_location_service.get_recommendations.assert_called_once_with(
            user_types=['restaurant', 'food'],
            user_lat=None,
            user_lng=None,
            top_n=20,
            max_distance=None,
            city='Kyiv'
        )
        assert len(result) == 2
        assert result[0].name == 'Restaurant A'
        assert result[1].name == 'Cafe B'
    
    @pytest.mark.asyncio
    async def test_get_recommendations_city_and_max_distance(self, location_controller, mock_location_service, sample_dataframe):
        """Test controller when city and max_distance are provided"""
        # Arrange
        mock_location_service.get_recommendations.return_value = sample_dataframe
        request = LocationRecommendationRequest(
            user_types=['cafe'],
            city='Lviv',
            max_distance=5.0
        )
        
        # Act
        result = await location_controller.router.routes[0].endpoint(request)
        
        # Assert
        mock_location_service.get_recommendations.assert_called_once_with(
            user_types=['cafe'],
            user_lat=None,
            user_lng=None,
            top_n=20,
            max_distance=5.0,
            city='Lviv'
        )
        assert len(result) == 2
    
    @pytest.mark.asyncio
    async def test_get_recommendations_only_user_coordinates(self, location_controller, mock_location_service, sample_dataframe):
        """Test controller when only user lat/lng is provided"""
        # Arrange
        mock_location_service.get_recommendations.return_value = sample_dataframe
        request = LocationRecommendationRequest(
            user_types=['restaurant'],
            user_lat=50.4501,
            user_lng=30.5234
        )
        
        # Act
        result = await location_controller.router.routes[0].endpoint(request)
        
        # Assert
        mock_location_service.get_recommendations.assert_called_once_with(
            user_types=['restaurant'],
            user_lat=50.4501,
            user_lng=30.5234,
            top_n=20,
            max_distance=None,
            city=None
        )
        assert len(result) == 2
    
    @pytest.mark.asyncio
    async def test_get_recommendations_user_coordinates_and_max_distance(self, location_controller, mock_location_service, sample_dataframe):
        """Test controller when user coordinates and max_distance are provided"""
        # Arrange
        mock_location_service.get_recommendations.return_value = sample_dataframe
        request = LocationRecommendationRequest(
            user_types=['food', 'restaurant'],
            user_lat=49.8397,
            user_lng=24.0297,
            max_distance=10.0,
            top_n=15
        )
        
        # Act
        result = await location_controller.router.routes[0].endpoint(request)
        
        # Assert
        mock_location_service.get_recommendations.assert_called_once_with(
            user_types=['food', 'restaurant'],
            user_lat=49.8397,
            user_lng=24.0297,
            top_n=15,
            max_distance=10.0,
            city=None
        )
        assert len(result) == 2
    
    @pytest.mark.asyncio
    async def test_get_recommendations_exception_handling(self, location_controller, mock_location_service):
        """Test controller exception handling"""
        # Arrange
        mock_location_service.get_recommendations.side_effect = Exception("Service error")
        request = LocationRecommendationRequest(
            user_types=['restaurant'],
            city='Kyiv'
        )
        
        # Act & Assert
        with pytest.raises(HTTPException) as exc_info:
            await location_controller.router.routes[0].endpoint(request)
        
        assert exc_info.value.status_code == 500
        assert "Service error" in str(exc_info.value.detail)