from fastapi import APIRouter, HTTPException, Depends
from typing import List

from models.schemas import LocationRecommendationRequest, LocationResponse
from services.location import LocationService

class LocationController:
    def __init__(self, location_service: LocationService):
        self.location_service = location_service
        self.router = APIRouter(prefix="/locations", tags=["locations"])
        self._setup_routes()
    
    def _setup_routes(self):
        @self.router.post("/recommendations", response_model=List[LocationResponse])
        async def get_recommendations(request: LocationRecommendationRequest):
            try:
                recommendations = self.location_service.get_recommendations(
                    user_types=request.user_types,
                    user_lat=request.user_lat,
                    user_lng=request.user_lng,
                    top_n=request.top_n,
                    max_distance=request.max_distance,
                    city=request.city,
                )
                
                return recommendations
                
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))
            

        @self.router.post("/recommendations/seed-database")
        async def seed_database_from_json():
            try:
                return self.location_service.seed_database_from_json(
                )
                
                
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))            