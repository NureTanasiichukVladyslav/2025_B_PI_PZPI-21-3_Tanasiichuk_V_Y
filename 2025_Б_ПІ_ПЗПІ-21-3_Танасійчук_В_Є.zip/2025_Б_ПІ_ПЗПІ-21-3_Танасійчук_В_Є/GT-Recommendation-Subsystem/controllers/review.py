from fastapi import APIRouter, HTTPException
from models.schemas import ReviewAnalysisRequest, ReviewAnalysisResponse
from services import ReviewService


class ReviewController:
    def __init__(self, review_service: ReviewService):
        self.review_service = review_service
        self.router = APIRouter(prefix="/reviews", tags=["reviews"])
        self._setup_routes()
    
    def _setup_routes(self):
        @self.router.post("/analyze", response_model=ReviewAnalysisResponse)
        async def analyze_review(request: ReviewAnalysisRequest):
            try:
                analysis_result = self.review_service.analyze_review(
                    rating=request.rating,
                    text=request.text
                )
                
                return ReviewAnalysisResponse(**analysis_result)
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))