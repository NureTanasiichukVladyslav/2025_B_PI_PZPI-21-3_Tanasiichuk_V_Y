import pytest
from unittest.mock import Mock
from fastapi import HTTPException

from .review import ReviewController
from models.schemas import ReviewAnalysisRequest
from services.review import ReviewService


class TestReviewController:
    
    @pytest.fixture
    def mock_review_service(self):
        return Mock(spec=ReviewService)
    
    @pytest.fixture
    def review_controller(self, mock_review_service):
        return ReviewController(mock_review_service)
    
    @pytest.mark.asyncio
    async def test_analyze_review_success(self, review_controller, mock_review_service):
        """Test successful review analysis"""
        # Arrange
        mock_analysis_result = {
            'fake_probability': 0.3,
            'confidence_score': 0.8,
            'is_fake': False,
            'analysis_factors': {
                'text_complexity': {'avg_word_length': 5.2, 'unique_words_ratio': 0.8},
                'suspicious_patterns': {'excessive_punctuation': 0, 'all_caps_words': 1},
                'sentiment_correlation': {'text_sentiment': 0.5, 'sentiment_rating_difference': 0.2},
                'content_relevance': {'location_relevance': 0.6, 'has_specifics': True}
            }
        }
        mock_review_service.analyze_review.return_value = mock_analysis_result
        
        request = ReviewAnalysisRequest(
            rating=5,
            text="Great restaurant with excellent service and delicious food. The staff was very friendly and the atmosphere was perfect for a dinner."
        )
        
        # Act
        result = await review_controller.router.routes[0].endpoint(request)
        
        # Assert
        mock_review_service.analyze_review.assert_called_once_with(
            rating=5,
            text="Great restaurant with excellent service and delicious food. The staff was very friendly and the atmosphere was perfect for a dinner."
        )
        assert result.fake_probability == 0.3
        assert result.confidence_score == 0.8
        assert result.is_fake is False
        assert 'text_complexity' in result.analysis_factors
    
    @pytest.mark.asyncio
    async def test_analyze_review_exception_handling(self, review_controller, mock_review_service):
        """Test review controller exception handling"""
        # Arrange
        mock_review_service.analyze_review.side_effect = Exception("Analysis error")
        request = ReviewAnalysisRequest(
            rating=3,
            text="Average place"
        )
        
        # Act & Assert
        with pytest.raises(HTTPException) as exc_info:
            await review_controller.router.routes[0].endpoint(request)
        
        assert exc_info.value.status_code == 500
        assert "Analysis error" in str(exc_info.value.detail)