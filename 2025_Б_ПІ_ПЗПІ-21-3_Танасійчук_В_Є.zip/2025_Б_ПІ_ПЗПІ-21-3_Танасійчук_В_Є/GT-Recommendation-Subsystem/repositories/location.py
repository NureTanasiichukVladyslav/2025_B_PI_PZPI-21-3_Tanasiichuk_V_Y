import json
from pathlib import Path
import pandas as pd
from typing import List
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, selectinload

from models.database_models import Place, Types

class LocationRepository:
    def __init__(self, engine):
        self.engine = engine

    def get_all_locations(self) -> pd.DataFrame:
        with Session(self.engine) as session:
            places = session.query(Place).options(
                selectinload(Place.types),  # Load categories
                selectinload(Place.tags)    # Load tags
            ).all()

            rows = []
            for place in places:
                type_names = [t.Name for t in place.types]
                tag_names = [t.Name for t in place.tags]

                rows.append({
                    "id": str(place.Id),
                    "name": place.Name,
                    "lat": place.Lat,
                    "lng": place.Lng,
                    "vicinity": place.Vicinity,
                    "google_place_id": place.GooglePlaceId,
                    "rating": place.Rating,
                    "user_ratings_total": place.UserRatingsTotal,
                    "types": type_names,
                    "types_str": ' '.join(type_names),
                    "tags": tag_names,
                    "tags_str": ' '.join(tag_names)
                })

            return pd.DataFrame(rows)

   
    def seed_categories(self):
        """Seed the Categories table with predefined types"""
        types = [
            "amusement_park",
            "aquarium",
            "art_gallery",
            "atm",
            "bakery",
            "bank",
            "bar",
            "beauty_salon",
            "book_store",
            "bowling_alley",
            "bus_station",
            "cafe",
            "campground",
            "car_rental",
            "casino",
            "cemetery",
            "church",
            "city_hall",
            "clothing_store",
            "convenience_store",
            "department_store",
            "doctor",
            "drugstore",
            "embassy",
            "florist",
            "gas_station",
            "hair_care",
            "hindu_temple",
            "home_goods_store",
            "hospital",
            "library",
            "light_rail_station",
            "liquor_store",
            "lodging",
            "meal_delivery",
            "meal_takeaway",
            "mosque",
            "movie_theater",
            "museum",
            "night_club",
            "painter",
            "park",
            "parking",
            "pharmacy",
            "police",
            "post_office",
            "restaurant",
            "shopping_mall",
            "spa",
            "stadium",
            "store",
            "subway_station",
            "supermarket",
            "synagogue",
            "taxi_stand",
            "tourist_attraction",
            "train_station",
            "transit_station",
            "travel_agency",
            "university",
            "zoo",
        ]

        try:
            with Session(self.engine) as session:
                for type_name in types:
                    # Check if type already exists
                    existing_type = session.query(Types).filter_by(Name=type_name).first()
                    if not existing_type:
                        new_type = Types(Name=type_name)
                        session.add(new_type)
                
                session.commit()
                print(f"Seeded {len(types)} categories")
        except SQLAlchemyError as e:
            print(f"Database error during category seeding: {e}")
            session.rollback()
        except Exception as e:
            print(f"Unexpected error during category seeding: {e}")

    def seed_database_from_json(self, json_path: str):
        """Seed the places table with data from a JSON file and establish relationships"""
        try:
            # First, ensure categories are seeded
            self.seed_categories()
            
            # Read JSON file
            json_path = Path(json_path)
            if not json_path.exists():
                print(f"JSON file not found at {json_path}")
                return
            with json_path.open('r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                print("JSON data must be a list of place objects")
                return

            with Session(self.engine) as session:
                # Create a mapping of type names to Type objects for efficiency
                type_mapping = {}
                all_types = session.query(Types).all()
                for type_obj in all_types:
                    type_mapping[type_obj.Name] = type_obj

                for item in data:
                    # Skip if place_id already exists
                    existing_place = session.query(Place).filter_by(GooglePlaceId=item.get('place_id')).first()
                    if existing_place:
                        print(f"Skipping duplicate place_id: {item.get('place_id')}")
                        continue
                    
                    # Map JSON fields to Place model
                    place = Place(
                        Name=item.get('name', ''),
                        Lat=item.get('geometry', {}).get('location', {}).get('lat', 0.0),
                        Lng=item.get('geometry', {}).get('location', {}).get('lng', 0.0),
                        Vicinity=item.get('vicinity', None),
                        GooglePlaceId=item.get('place_id', ''),
                        Rating=item.get('rating', None),
                        UserRatingsTotal=item.get('user_ratings_total', None)
                    )
                    
                    # Add place to session first
                    session.add(place)
                    session.flush()  # This will assign an ID to the place
                    
                    # Establish many-to-many relationships with types
                    place_types = item.get('types', [])
                    for type_name in place_types:
                        if type_name in type_mapping:
                            place.types.append(type_mapping[type_name])
                        
                
                session.commit()
                print(f"Seeded {len(data)} places from {json_path}")
        except json.JSONDecodeError:
            print(f"Invalid JSON format in {json_path}")
        except SQLAlchemyError as e:
            print(f"Database error during seeding: {e}")
            session.rollback()
        except Exception as e:
            print(f"Unexpected error during seeding: {e}")