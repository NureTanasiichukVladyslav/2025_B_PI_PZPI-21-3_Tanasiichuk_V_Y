export type Reply = {
	id: string;
	userId: string;
	username: string;
	text: string;
	date: string;
	isOwn: boolean;
	images: string[];
};
