export type TravelCategory = {
	categoryId: string;
	name: string;
};
