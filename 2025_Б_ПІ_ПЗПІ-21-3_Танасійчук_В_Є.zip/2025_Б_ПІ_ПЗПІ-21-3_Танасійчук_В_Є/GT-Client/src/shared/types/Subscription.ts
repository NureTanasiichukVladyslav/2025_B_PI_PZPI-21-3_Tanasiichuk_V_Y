export type Subscription = {
	subscriptionId: string;
	firstName: string;
	lastName: string;
	since: string;
	subscribers: number;
	rating: number;
	reviews: number;
};
