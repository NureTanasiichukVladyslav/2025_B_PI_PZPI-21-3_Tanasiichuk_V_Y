export type TravelTag = {
	tagId: string;
	name: string;
};
