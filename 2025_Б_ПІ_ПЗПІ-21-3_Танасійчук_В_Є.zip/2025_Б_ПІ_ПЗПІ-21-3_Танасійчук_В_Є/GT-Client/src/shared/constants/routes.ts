export enum ROUTES {
	LOGIN = "/login",
	REGISTRATION = "/register",
	PROFILE = "/profile",
	PLACES = "/places",
	REPORTS = "/reports",
	PREFERENCES = "/preferences",
	USERS = "/users",
	RESTOREPASSWORD = "/restore-password",
}
