export const reportReasons = [
	{ label: "Sexual Harassment", value: 0 },
	{ label: "Extremism", value: 1 },
	{ label: "Hate Speech", value: 2 },
	{ label: "Spam", value: 3 },
	{ label: "Other", value: 4 },
];

export const ENTITY_REVIEW = 1;
export const ENTITY_REPLY = 2;
