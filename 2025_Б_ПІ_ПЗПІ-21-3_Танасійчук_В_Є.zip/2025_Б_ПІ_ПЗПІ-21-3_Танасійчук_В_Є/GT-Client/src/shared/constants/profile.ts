export const PROFILE_TAB = 0;
export const MONETIZATION_TAB = 1;
export const SUBSCRIPTIONS_TAB = 2;
export const SECURITY_TAB = 3;

export const DONATION_RECEIVED = 0;
export const DONATION_SENT = 1;
