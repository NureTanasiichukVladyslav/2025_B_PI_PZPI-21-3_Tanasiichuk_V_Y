export const ROLE_USER = 0;
export const ROLE_ADMINISTRATOR = 1;

export const mockedUser = {
	userId: "1234-5678-9012-3456",
	role: ROLE_ADMINISTRATOR,
	login: "illiateliuk",
	email: "illiateliuk@gmail.com",
	username: "hereIsJohnny",
	firstName: "Illia",
	lastName: "Teliuk",
	token: "superToken",
	bio: "I love you",
	rating: 4.9,
	reviewsCount: 6,
	joinDate: "12-04-2025",
};
