export { default as GoogleIcon } from "./GoogleIcon";
export { default as LogoIcon } from "./GoogleIcon";
