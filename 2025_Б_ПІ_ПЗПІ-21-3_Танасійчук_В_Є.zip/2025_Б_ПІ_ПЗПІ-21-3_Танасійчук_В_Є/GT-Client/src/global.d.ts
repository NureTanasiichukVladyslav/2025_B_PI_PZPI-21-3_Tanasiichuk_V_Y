declare module "*.css";
declare module "*.png";
declare module "*.jpg";
